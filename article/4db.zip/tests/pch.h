#pragma once

#include "CppUnitTest.h"

#include "includes.h"

#pragma comment(lib, "4db")